public class Person{
	String fName,lName, stuStat;
	int stuId;
	
	public static void main(String[] args) {
		
		Person p = new Person();

		p.fName = "Lisa";
		p.lName = "Palombo";
		p.stuId = 123456789;
		p.stuStat = "Active";


		System.out.println(p.fName+" "+p.lName+", "+p.stuId+", "+p.stuStat);			

	}

}