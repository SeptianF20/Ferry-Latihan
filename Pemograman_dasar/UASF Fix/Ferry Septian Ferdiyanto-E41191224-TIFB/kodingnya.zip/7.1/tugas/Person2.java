public class Person2{
	String fName,lName, stuStat;
	int stuId;
	
	public static void main(String[] args) {
		
		Person2 p = new Person2();

		p.setName("alif","irhas");
		p.setStuId(123456789);
		p.setStuStat("Active");

		System.out.println(p.getName());		
		System.out.println(p.getStuId());		
		System.out.println(p.getStuStat());		

	}

	public void setName(String fName, String lName){
		this.fName = fName;
		this.lName = lName;
	}
	public void setStuId(int stuId){
		this.stuId = stuId;
	}
	public void setStuStat(String stuStat){
		this.stuStat = stuStat;
	}


	public String getName(){
		return this.fName+" "+this.lName;
	}
	public int getStuId(){
		return this.stuId;
	}
	public String getStuStat(){
		return this.stuStat;
	}


}