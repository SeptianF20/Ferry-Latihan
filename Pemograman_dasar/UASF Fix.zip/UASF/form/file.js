function data() {
	// body...

	/*menyimpan inputan dari form berdasarkan name di dalam variabel*/
	var nim = (document.mahasiswa.nim.value);
	var nama = (document.mahasiswa.nama.value);
	var agama = (document.mahasiswa.agama.value);
	var essay = (document.mahasiswa.essay.value);
	var jk = "";
	if(document.mahasiswa.LK.checked == true){
		jk = "Laki - Laki"
	}else if (document.mahasiswa.LK.checked == true) {
		jk = "Wanita"
	}
	var status = "";
	if (document.mahasiswa.Menikah.checked == true) {
		status = "Menikah";
	}else if (document.mahasiswa.BelumMenikah.checked == true) {
		status = "Belum Menikah";
	}else {
		status = "";
	}

	var prodi = "";
	if (document.mahasiswa.TIF.checked == true) {
		prodi = "TIF";
	}else if (document.mahasiswa.MIF.checked == true) {
		prodi = "MIF";
	}else if (document.mahasiswa.TKK.checked == true) {
		prodi = "TKK";
	}else{
		prodi = "";
	}

					/*selese*/

	/*mengeluarkan data dari dalam variabel*/
	document.mahasiswa.nimout.value = nim;
	document.mahasiswa.namaout.value = nama;
	document.mahasiswa.jkout.value = jk;
	document.mahasiswa.agamaout.value = agama;
	document.mahasiswa.statusout.value = status;
	document.mahasiswa.prodiout.value = prodi;
	document.mahasiswa.essayout.value = essay;
}